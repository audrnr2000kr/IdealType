class Idle {
  final String _name;

  Idle(
      this._name

      );

  String get name => _name;


  @override
  String toString() {
    return _name;
  }
}
