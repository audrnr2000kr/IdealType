class Category {
  final String cupName;
  final String imgName;
  int win;

  Category ({ required this.cupName, required this.imgName, required this.win });
}