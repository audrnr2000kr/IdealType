import 'package:flutter/material.dart';
import 'landing_page.dart';

class ResultPage extends StatelessWidget {
  final String _name;

  ResultPage(this._name);

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
